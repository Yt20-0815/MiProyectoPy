from flask import Blueprint, render_template

taskRoute = Blueprint("task",__name__, url_prefix="/tasks")

@taskRoute.route("/")
def index():
    return render_template("index.html", name="Pancrasio")


# @taskRoute.route("/<int:id>")
# def id(id:int):
#     return "Mostrando id " + str(id)

@taskRoute.route("/create", methods= ["GET","POST"])
def create():
    return "Objeto creado"

@taskRoute.route("/<info>")
def info(info:str):
    nueva_info = "La informacion a mostrar es la siguiente: "+info
    return render_template("datos.html",informacion=nueva_info)