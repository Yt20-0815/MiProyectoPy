from flask import Flask
app = Flask(__name__)

from task.controllers import taskRoute

app = Flask(__name__)

app.register_blueprint(taskRoute)

if __name__ == "__main__":
    app.debug = True
    app.run()