from flask import Flask

from task.controllers import taskRoute

app = Flask(__name__)

app.register_blueprint(taskRoute)