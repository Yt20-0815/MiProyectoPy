import React, { useState, useEffect } from 'react';
import './ProductosTable.css';

const ProductosTable = () => {
  const [productos, setProductos] = useState([]);

  useEffect(() => {
    fetch('/productos.json')
      .then(response => response.json())
      .then(data => setProductos(data));
  }, []);

  return (
    <table className="productos-table">
      <thead>
        <tr>
          <th>ID</th>
          <th>Nombre</th>
          <th>Precio</th>
          <th>Descuento (%)</th>
          <th>Existencia</th>
          <th>Precio con Descuento</th>
        </tr>
      </thead>
      <tbody>
        {productos.map(producto => {
          const precioConDescuento = producto.precio * (1 - producto.descuento / 100);
          return (
            <tr key={producto.id}>
              <td>{producto.id}</td>
              <td>{producto.nombre}</td>
              <td>${producto.precio}</td>
              <td>{producto.descuento}%</td>
              <td>{producto.existencia}</td>
              <td>${precioConDescuento.toFixed(2)}</td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
};

export default ProductosTable;