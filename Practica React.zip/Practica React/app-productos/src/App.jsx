import React, { useState } from 'react';
import ProductosTable from './assets/ProductosTable';
import './App.css'; // Importa los estilos CSS

function App() {
  const [mostrarTabla, setMostrarTabla] = useState(false);

  const mostrarProductos = () => {
    setMostrarTabla(true);
  };

  return (
    <div className="App">
      {!mostrarTabla ? (
        <div className="inicio">
          <h1>Bienvenido a la Tienda</h1>
          <button onClick={mostrarProductos}>Ver Productos</button>
        </div>
      ) : (
        <div>
          <h1>Lista de Productos</h1>
          <ProductosTable />
          <button onClick={() => setMostrarTabla(false)}>Volver al Inicio</button>
        </div>
      )}
    </div>
  );
}

export default App;